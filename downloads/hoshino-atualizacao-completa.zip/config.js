module.exports = {
  PREFIXO: "!",
  NOME_BOT: "Tomioka Bot",
  VERSAO: "2.0.9", // <-- Atualize essa versão a cada deploy
  DONO_PRINCIPAL_NOME: "Atlas",
  DONO_PRINCIPAL_NUMERO: "+55 81 9810-7828",
  DONO_PRINCIPAL_LID: "102586115948766", // LID do dono para verificação (pegue usando !meulid no chat)
  bronxysApiKey: "adquira_sua_key_bronxy_apis",
  API_KEY_GEMINI: "SUA_CHAVE_GEMINI_AQUI",
  LICENCA: "MEUBOT-AE18C13C-7E27A1DE-2C4C92D6",
  NUMERO_BOT: "Paulo"
};
